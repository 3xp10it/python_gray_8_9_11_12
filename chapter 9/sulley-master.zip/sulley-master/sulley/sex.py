# Sulley EXception Class

class SullyRuntimeError(Exception):
    pass